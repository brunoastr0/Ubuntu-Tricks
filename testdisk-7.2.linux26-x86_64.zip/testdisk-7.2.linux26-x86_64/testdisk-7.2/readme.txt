This Linux version of TestDisk & PhotoRec should work on any 2.6 or later
x86_64 kernel. It's a static version, the binary doesn't depend on
shared libraries.

TestDisk & PhotoRec documentation can be found online:
- https://www.cgsecurity.org/wiki/TestDisk
- https://www.cgsecurity.org/wiki/PhotoRec
